<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
                <div class="card">
                        <div class="card-header">รายการสินค้า</div>

                        <div class="card-body">
                                <table class="table table-striped">
                                        <thead>
                                          <tr>
                                            <th>ลำดับ</th>
                                            <th>ชื่อ</th>
                                            <th>ราคา</th>
                                            <th>ประเภท</th>
                                            <th></th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($ls->product_id); ?></td>
                                                <td><?php echo e($ls->product_name); ?></td>
                                                <td><?php echo e($ls->price); ?></td>
                                                <td><?php echo e($ls->type_name); ?></td>
                                                <td><a href="edit/<?php echo e($ls->product_id); ?>"> <button class="btn btn-warning">แก้ไข</button></a></td>
                                            </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                </table>
                        </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>