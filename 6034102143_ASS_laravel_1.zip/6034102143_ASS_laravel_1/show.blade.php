@foreach ($members as $student)
{{$student->first_name}} {{$student->last_name}}<br>

@endforeach
